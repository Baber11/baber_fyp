@extends('admin.adminsidenav')

@section('viewsite')
active
@endsection

@section('content')
<section class="forms">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-4 mt-3">
        <h1 class="font-weight-bold mt-2 admin_dashboard"><u>Company Site</u></h1>
      </div>
    </div>
  </div>





</section> 
@endsection