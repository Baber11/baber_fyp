<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-1.0">
	<meta http-equiv="X-UA-compatible" content="ie=edge">
	<!-- <link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet"> -->
	<title>PDF</title>
</head>
<style type="">
h1 , h2 , h3 , h4 , h5 , h6 , p , span , u , b ,i{
	font-family: 'Ubuntu', sans-serif;
}
button{
	font-size: 25px;
	color: white;
	background-color: #ff9b44;
	border: none;
	border-radius: 7px;
	/* width: 138px; */
	/* height: 45px; */
	padding: 8px 34px;
}
.payslip_heading{
	display: flex;
	justify-content: center;
	margin-top: 10px
}
.payslip_emp_info{
	padding-left: 53px;
	margin-top: 41px

}
.slip_card{
	display: flex;
	justify-content: space-between;
	margin-top:20px;
	border-bottom:solid 1px #ff9b44;
}
.slip_card div h2{
	margin-top: 1rem;
}
.slip_card_width{
	display: flex;
	justify-content: space-around;
	margin-top: 41px;
}
.pdf_heading{
	color: dimgray;
	font-size: 35px;
}
.card-header{
	background: #ff9b44;
	color: white;
	margin-top: 14px;
	padding: 1px 13px;
	border-radius: 14px;
}
.pdf_down{
	display: flex;
	justify-content: end;
	padding-bottom: 13px;
	padding-right: 19px;
}
body{
	display: flex;
	justify-content: center;
}
</style>
<div class="pdf_down">
	<a href="{{url('/downloadpdf')}}/{{$sal->id}}"><button style="margin-right: 5px;"> Download</button></a>
	<!-- <button >Save</button> -->
</div>
<body>
	<div style="width: 70%;border:solid 6px #ff9b44">
		<section>
			<div class="payslip_heading">
				<h1 class="pdf_heading"><b><u><i>PAYSLIP FOR THE MONTH OF {{$sal->month}} {{$sal->year}}</i></u></b></h1>
			</div>
		</section>
		<section>
			<div style="display: flex; justify-content: space-between;padding: 0px 32px;">
				
				<div>
					<h1>Company Name :
						<span style="color: #ff9b44;letter-spacing: 2px;font-size: 26px;">
							<u> {{$comp->company_name}}</u>
						</span>
					</h1>
					<h2>Reg. no : <span style="color:#ff9b44">FT-00{{$sal->emp_reg}}</span> </h2>
					<h2>Employee Name : <span style="color:#ff9b44">{{$sal->emp_name}}</span></h2>
					<h2>Designation : <span style="color:#ff9b44"> {{$sal->designation}}</span></h2>
					<h2>Department : <span style="color:#ff9b44"> {{$sal->dept}}</span></h2>
				</div>
				<div class="payslip_emp_info">
					<h2>PAYSLIP <span style="color:#ff9b44"># {{$sal->id}}</span> </h2>
					<h2>Salary Month: <span style="color:#ff9b44"> {{$sal->month}}</span> </h2>
				</div>
			</div>
		</section>
		<div class="slip_card_width">
			<div class="card" style="width: 44% ;border: solid lightgray 1px;
			padding: 0px 17px 17px 17px ;">
			<div class="card-header"><h2 >Earnings</h2></div>
			<div class="card-body">
				<div class="slip_card">
					<div><h3>Basic Salary</h3></div>
					<div><h2>{{$sal->basic_pay}} PKR</h2></div>
				</div>
				<div class="slip_card">
					<div><h3>Transport Allownace:</h3></div>
					<div><h2>{{$sal->travel_allowance}} PKR</h2></div>
				</div>
				<div class="slip_card">
					<div><h3>Medical Allowance</h3></div>
					<div><h2>{{$sal->medical_allowance}} PKR</h2></div>
				</div>
				<div class="slip_card">
					<div><h3>Total Working Days</h3></div>
					<div><h2>{{$sal->present_days}}</h2></div>
				</div>
			</div>
		</div>
		<div class="card" style="width: 44% ;border: solid lightgray 1px;
		padding: 0px 17px 17px 17px ;">
		<div class="card-header"><h2 >Deductions</h2></div>
		<div class="card-body">
			<div class="slip_card">
				<div><h3>Absents</h3></div>
				<div><h2>{{$sal->absent_days}}</h2></div>
			</div>
			<div class="slip_card">
				<div><h3>Provident Fund</h3></div>
				<div><h2>{{$sal->p_fund}} PKR</h2></div>
			</div>
		</div>
	</div>

</div>
<div class="payslip_emp_info">
	<h3>
		Net Salary: {{$amount}} PKR  (<span id="amt"></span> Rupees Only )
	</h3>
</div>


</div>
</body>
<script>
	var amount= "<?php echo"$amount"?>";
	//console.log(amount);
	const num = amount;
	const wordify = (num) => {
		const single = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
		const double = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
		const tens = ["", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
		const formatTenth = (digit, prev) => {
			return 0 == digit ? "" : " " + (1 == digit ? double[prev] : tens[digit])
		};
		const formatOther = (digit, next, denom) => {
			return (0 != digit && 1 != next ? " " + single[digit] : "") + (0 != next || digit > 0 ? " " + denom : "")
		};
		let res = "";
		let index = 0;
		let digit = 0;
		let next = 0;
		let words = [];
		if (num += "", isNaN(parseInt(num))){
			res = "";
		}
		else if (parseInt(num) > 0 && num.length <= 10) {
			for (index = num.length - 1; index >= 0; index--) switch (digit = num[index] - 0, next = index > 0 ? num[index - 1] - 0 : 0, num.length - index - 1) {
				case 0:
				words.push(formatOther(digit, next, ""));
				break;
				case 1:
				words.push(formatTenth(digit, num[index + 1]));
				break;
				case 2:
				words.push(0 != digit ? " " + single[digit] + " Hundred" + (0 != num[index + 1] && 0 != num[index + 2] ? " and" : "") : "");
				break;
				case 3:
				words.push(formatOther(digit, next, "Thousand"));
				break;
				case 4:
				words.push(formatTenth(digit, num[index + 1]));
				break;
				case 5:
				words.push(formatOther(digit, next, "Lakh"));
				break;
				case 6:
				words.push(formatTenth(digit, num[index + 1]));
				break;
				case 7:
				words.push(formatOther(digit, next, "Crore"));
				break;
				case 8:
				words.push(formatTenth(digit, num[index + 1]));
				break;
				case 9:
				words.push(0 != digit ? " " + single[digit] + " Hundred" + (0 != num[index + 1] || 0 != num[index + 2] ? " and" : " Crore") : "")
			};
			res = words.reverse().join("")
		} else res = "";
		return res
	};
	var am= (wordify(num));
	console.log(am);
	$("#amt").html(am);
</script>

</html>