<style>
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button
  {
    -webkit-appearance: none;
    margin: 0;
  }
</style>



<?php $__env->startSection('adddept'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<section class="forms">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-4 mt-3">
        <h1 class="font-weight-bold mt-2 admin_dashboard"><u>Add Departments</u></h1>
      </div>
    </div>
  </div>

  <div class="container-fluid">
    <div class="row">


      <div class="col-md-5">
       <?php if(session()->has('success')): ?>
       <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

      </div>
      <?php endif; ?>
      <div class="card shadow-lg mt-4">
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('admin.dept')); ?>">
            <?php echo csrf_field(); ?>
             <!--  <label class="wrapper mt-4">
                <div class="emp_input_div">
                  <input type="number" class="textfield textfield_forms_resp" placeholder=" " >
                  <span class="placeholder">Department ID </span>
                </div>
              </label> -->
              <label class="wrapper mt-4">
                <div class="emp_input_div">
                  <input type="text" class="textfield textfield_forms_resp" placeholder=" " name="dept" autocomplete="off">
                  <span class="placeholder">Department Name</span>
                </div>
                <?php if($errors->has('dept')): ?>
                <small class="text-danger">
                  <?php echo e($errors->first('dept')); ?>

                </small>
                <?php endif; ?>
              </label>
              <div class="row">
                <div class="col-md-12 text-center col-12">
                  <div class="container-login100-form-btn m-t-32">
                    <button type="submit" class="login100-form-btn">
                      Save
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-6 mt-n2">
        <img src="<?php echo e(asset('img/adddept.jpg')); ?>" alt="person" class=" add_emp_form_pic img-fluid "
        height="1000" width="997">
      </div>
    </div>
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="card shadow border-top mt-n3">
          <div class="card-body">
            <?php if(isset($errors) && count($errors) > 0): ?>
            <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <?php endif; ?>
            <div class="table-responsive">
              <table class="table table-striped table-hover" >
                <thead>
                  <tr style="color: #ff9b44">
                    <th>Dept ID</th>
                    <th >Dept Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($d->id); ?></th>
                    <td ><?php echo e($d->dept_name); ?></td>
                    <td><button value="<?php echo e($d->id); ?>" type="button" class="editbtn"><i class=" text-dark ml-1 far fa-edit"></i></button></td>
                    <td>
                      <form action="<?php echo e(route('admin.deletedept')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($d->id); ?>">
                        <button name="submit"><i class=" text-dark ml-3 fas fa-trash"></i></button>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- Edit modal -->
  
  <div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="d-flex justify-content-end p-2 mt-n1"><button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" class="modal_close" style="">&times;</span>
        </button></div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <div>
                <h5 class="modal-title text-center" style="font-size: 22px" id="exampleModalLongTitle" >Update Department</h5>
                
                <form method="POST" action="<?php echo e(route('admin.updatedept')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" id="dept_id" name="dept_id">

                  <label class="wrapper mt-4">
                    <div class="emp_input_div">
                      <input type="text" class="textfield textfield_forms_resp" placeholder=" " id="dname" name="dept" >
                      <span class="placeholder"> Department Name </span>
                      <?php if($errors->has('dept')): ?>
                      <small class="text-danger">
                        <?php echo e($errors->first('dept')); ?>

                      </small>
                      <?php endif; ?>

                    </div> 
                  </label>
                  
                  <div class="container-login100-form-btn m-t-32">
                    <button type="submit" class="login100-form-btn">
                      Update
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end edit modal -->
  <script>
    

    //editbtn
    $(document).ready(function(){
      $(document).on('click', '.editbtn', function(){
        var dept_id = $(this).val();
        $('#dept_id').val(dept_id);
      //alert(dept_id);
      $('#editmodal').modal('show');
      console.log("<?php echo e(url('/')); ?>/admin/editdept"+'/'+ dept_id);
      $.ajax({
        type: "GET",
        url: "<?php echo e(url('/')); ?>/admin/editdept"+'/'+ dept_id,


        success: function (response){
                                    // DBcolname
                                    console.log(response.edit.dept_name);
                                    $('#dname').val(response.edit.dept_name);
                                  }

                                });

    });
    });

    //clear
    function myFunction() {
      document.getElementById("mybtn").reset();
    }
  </script>
</section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminsidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp\resources\views/admin/adddept.blade.php ENDPATH**/ ?>