

<!-- add employees form start here -->
<style>
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button
{
	-webkit-appearance: none;
	margin: 0;
}
</style>
<style>
.switch {
	position: relative;
	display: inline-block;
	width: 60px;
	height: 34px;
}

.switch input { 
	opacity: 0;
	width: 0;
	height: 0;
}

.slider {
	position: absolute;
	cursor: pointer;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-color: #ccc;
	-webkit-transition: .4s;
	transition: .4s;
}

.slider:before {
	position: absolute;
	content: "";
	height: 26px;
	width: 26px;
	left: 4px;
	bottom: 4px;
	background-color: white;
	-webkit-transition: .4s;
	transition: .4s;
}

input:checked + .slider {
	background-color: #e82f87;
}

input:focus + .slider {
	box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
	-webkit-transform: translateX(26px);
	-ms-transform: translateX(26px);
	transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
	border-radius: 34px;
}

.slider.round:before {
	border-radius: 50%;
}
</style>

<?php $__env->startSection('empl'); ?>
active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('addemp'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="forms">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 mt-3 mb-3">
				<h1 class="font-weight-bold add_emp_heading"><u> Add New Employees</u></h1>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="card shadow-lg">
			<div class="card-body">
				<div class="row">
					<div class="col-md-7 col-12">
						<?php if(session()->has('success')): ?>
						<div class="alert alert-success">
							<?php echo e(session()->get('success')); ?>

						</div>
						<?php endif; ?>
						<form method="POST" action="<?php echo e(url('/createemp')); ?>" id="mybtn" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<label class="wrapper  mt-2">
								<div class="emp_input_div">
									<input type="text" class="textfield textfield_forms_resp" name= "fname" placeholder=" " value="<?php echo e(old('fname')); ?>" autocomplete="off">
									<span class="placeholder"> First Name </span>
									<?php if($errors->has('fname')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('fname')); ?>

									</small>
									<?php endif; ?>
								</div> 

							</label>
							
							<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="text" name= "lname" class="textfield textfield_forms_resp" placeholder=" " autocomplete="off" value="<?php echo e(old('lname')); ?>">
									<span class="placeholder"> Last Name </span>
									<?php if($errors->has('lname')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('lname')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="text" name= "cnic" class="textfield textfield_forms_resp" placeholder=" " autocomplete="off" value="<?php echo e(old('cnic')); ?>" >
									<span class="placeholder">Employee CNIC </span>
									<?php if($errors->has('cnic')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('cnic')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="date" name= "dob" class="textfield textfield_forms_resp" value="<?php echo e(old('dob')); ?>">
									<span class="placeholder"> Date Of Birth </span>
									<?php if($errors->has('dob')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('dob')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="text" name= "gender" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('gender')); ?>" >
									<span class="placeholder"> Gender </span>
									<?php if($errors->has('gender')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('gender')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="Email" name= "email" class="textfield textfield_forms_resp" placeholder=" " autocomplete="off" value="<?php echo e(old('email')); ?>">
									<span class="placeholder"> Email </span>
									<?php if($errors->has('email')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('email')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="number" name= "number" class="textfield textfield_forms_resp" autocomplete="off" placeholder=" " value="<?php echo e(old('number')); ?>">
									<span class="placeholder"> Phone Number </span>
									<?php if($errors->has('number')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('number')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="text" name= "address" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('address')); ?>">
									<span class="placeholder"> Residing Address </span>
									<?php if($errors->has('address')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('address')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="text" name= "city" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('city')); ?>">
									<span class="placeholder"> City </span>
									<?php if($errors->has('city')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('city')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<!-- <label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="text" name= "dept" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('dept')); ?>">
									<span class="placeholder"> Department </span>
									<?php if($errors->has('dept')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('dept')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label> -->

							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="text" name= "qualification" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('qualification')); ?>" >
									<span class="placeholder">Emp Qualification </span>
									<?php if($errors->has('qualification')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('qualification')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>

							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="number" name= "ex" class="textfield textfield_forms_resp" placeholder=" " autocomplete="off" value="<?php echo e(old('ex')); ?>" >
									<span class="placeholder"> Experience In Year </span>
									<?php if($errors->has('ex')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('ex')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>

							<label class="wrapper mt-4">
								<div class="emp_input_div" style="height: 49px;">
									
									<select name="dept" class="form-control border-0" style="">
										<?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php ($name=$n->dept_name); ?>
										<option value="" selected disabled hidden>Choose Deptartment</option>
										<option value="<?php echo e($n->id); ?>"> <?php echo e($name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</select>
									
								</div>
								<?php if($errors->has('dept')): ?>
								<small class="text-danger">
									<?php echo e($errors->first('dept')); ?>

								</small>
								<?php endif; ?>
							</label>

							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="date" name= "dateofjoining" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('dateofjoining')); ?>">
									<span class="placeholder"> Date of Joining </span>
									<?php if($errors->has('dateofjoining')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('dateofjoining')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>

							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="Password" id="pass_log_id"  name="password" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('password')); ?>">
									<span class="placeholder"> New password </span>
									<i style=" position: absolute;top: 23%;right: 1%;color: #555" class="fa fa-fw fa-eye field_icon fa-2x toggle-password"></i>
									<?php if($errors->has('password')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('password')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="Password" name= "cpassword" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('cpassword')); ?>">
									<span class="placeholder"> Confirm Password </span>
									<?php if($errors->has('cpassword')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('cpassword')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="file" class="form-control textfield textfield_forms_resp" name="profile_image">
									<!-- <span class="placeholder"> Confirm Password </span> -->
									<?php if($errors->has('profile_image')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('profile_image')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<!-- Form submit button -->
							<div class="row">
								<div class="col-md-3"></div>
								<div class="col-md-3 col-6">
									<div class="container-login100-form-btn m-t-32">
										<button type="submit" class="login100-form-btn">
											Submit
										</button>
									</div>
								</div>
								<div class="col-md-3 col-6">
									<div class="container-login100-form-btn m-t-32">
										<input type="button" class="login100-form-btn" onclick="myFunction()" value="Clear">							
									</div> 
								</div>
								<div class="col-md-3"></div>
							</div>

						</form>
					</div>
					<div class="col-md-5">
						<img src="<?php echo e(asset('img/form.jpg')); ?>" alt="person" class=" img-fluid mt-n0"
						height="1000" width="997">
					</div>
				</div>
			</div>
		</div>
	</div>
</section> 

<script>
	
	function myFunction() {
		document.getElementById("mybtn").reset();
	}
	

	//PASSWORD VIEW
	$(document).on('click', '.toggle-password', function() {
		$(this).toggleClass("fa-eye fa-eye-slash");
		var input = $("#pass_log_id");
		input.attr('type') === 'password' ? input.attr('type','text') : input.attr('type','password')
	});
</script>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('hr.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp\resources\views/hr/addemployee.blade.php ENDPATH**/ ?>