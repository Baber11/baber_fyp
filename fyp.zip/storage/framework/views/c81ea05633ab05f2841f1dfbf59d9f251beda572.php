

<!-- accounts INFO form start here -->
<style>
	input::-webkit-outer-spin-button,
	input::-webkit-inner-spin-button
	{
		-webkit-appearance: none;
		margin: 0;
	}
</style>
<?php $__env->startSection('act'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addact'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="forms">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 mt-3">
				<h1 class="font-weight-bold add_emp_heading"><u> Accounts Information</u></h1>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6">
				<div class="card shadow mt-4">
					<div class="card-body">
						<div>
							<div>
								<h1 class="font-weight-bold add_emp_heading mt-n1">BANK DETAILS:</h1>
							</div>
						</div>
						<?php if(session()->has('success')): ?>
						<div class="alert alert-success">
							<?php echo e(session()->get('success')); ?>

						</div>
						<?php endif; ?>
						<?php if(session()->has('error')): ?>
				<div class="alert alert-danger">
					<?php echo e(session()->get('error')); ?>

				</div>
				<?php endif; ?>
						<form method="POST" action="<?php echo e(url('/create')); ?>" id="mybtn">
							<?php echo csrf_field(); ?>
							<div id="img_p"></div>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									
									<input type="number" name="id" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('id')); ?>" id="reg_id" autocomplete="off">
									<span class="placeholder">Registraton Number:</span>
								
								<?php if($errors->has('id')): ?>
							<small class="text-danger">
								<?php echo e($errors->first('id')); ?>

							</small>
							<?php endif; ?>
						</div>
							</label>
							<label class="wrapper  mt-4  ">
								<div class="emp_input_div">
									<input type="text" name="bank_name" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('bank_name')); ?>" >
									<span class="placeholder">Bank Name:</span>
									<?php if($errors->has('bank_name')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('bank_name')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
							<label class="wrapper  mt-4 ">
								<div class="emp_input_div">
									<input type="text" name="account_type" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('account_type')); ?>">
									<span class="placeholder">Account Type:</span>
									<?php if($errors->has('account_type')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('account_type')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
							<label class="wrapper  mt-4 ">
								<div class="emp_input_div">
									<input type="number" name="acc_num" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('acc_num')); ?>" autocomplete="off">
									<span class="placeholder">Account No:</span>
									<?php if($errors->has('acc_num')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('acc_num')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
						
							<label class="wrapper  mt-4 ">
								<div class="emp_input_div">
									<input type="number" name="iban_num" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('iban_num')); ?>" autocomplete="off" >
									<span class="placeholder">IBAN No:</span>
									<?php if($errors->has('iban_num')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('iban_num')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
							<label class="wrapper  mt-4 ">
								<div class="emp_input_div">
									<input type="text" name="branch_add" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('branch_add')); ?>">
									<span class="placeholder">Branch Address:</span>
									<?php if($errors->has('branch_add')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('branch_add')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
							<label class="wrapper  mt-4 ">
								<div class="emp_input_div">
									<input type="number" name="branch_code" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('branch_code')); ?>" autocomplete="off">
									<span class="placeholder">Branch Code:</span>
									<?php if($errors->has('branch_code')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('branch_code')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
							<label class="wrapper  mt-4 ">
								<div class="emp_input_div">
									<input type="text" name="swift_code" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('swift_code')); ?>" autocomplete="off">
									<span class="placeholder">Swift Code:</span>
									<?php if($errors->has('swift_code')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('swift_code')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
							<div class="row">
								<div class="col-md-6 col-6">
									<div class="container-login100-form-btn m-t-32">
										<button type="submit" class="login100-form-btn">
											Save
										</button>
									</div>
								</div>
								<div class="col-md-6 col-6">
									<div class="container-login100-form-btn m-t-32">
										<input type="button" class="login100-form-btn" onclick="myFunction()" value="Clear">
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<img src="<?php echo e(asset('img/accounts.jpg')); ?>" alt="person" width="100%" class="img-fluid">
			</div>
		</div>
	</div>
	
</section> 
<script>
	

	$(document).ready(function(){
		$('#reg_id').keyup(function(){

			var reg=$(this).val();
			
			if(reg!=0)
			{
				$.ajax({
					type:'GET',
					url: "<?php echo e(url('/')); ?>/get_image/"+reg

				}).done(function(data){
					
					if(data.status)
					{
						$('#img_p').html(`<img src="<?php echo e(url("/")); ?>/uploads/emppic/`+data.img+`"width="150px" height="150px" alt="Image">`);
					}
					else
					{
						$('#img_p').html(' ');
					}
				});
			}
		});

	});
function myFunction() {
		document.getElementById("mybtn").reset();
	}
</script>
<?php $__env->stopSection(); ?>
<!-- <script>
	function myFunction() {
		document.getElementById("mybtn").reset();
	}
</script> -->

<?php echo $__env->make('hr.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp\resources\views/hr/accounts.blade.php ENDPATH**/ ?>