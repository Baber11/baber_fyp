
<!-- add employees form start here -->
<style>
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button
{
	-webkit-appearance: none;
	margin: 0;
}
</style>
<?php $__env->startSection('editemp'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="forms">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 mt-3 mb-3">
				<h1 class="font-weight-bold add_emp_heading"><u> Edit Employee</u></h1>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="card shadow-lg">
			<div class="card-body">
				<div class="row">
					<div class="col-md-7 col-12">
						<?php if(session()->has('success')): ?>
						<div class="alert alert-success">
							<h1><?php echo e(session()->get('success')); ?></h1>
						</div>
						<?php endif; ?>
						<form class="" method="POST" action="<?php echo e(url('/updateemp')); ?>" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>

							<label class="wrapper  mt-2">
								<div class="emp_input_div">
									<input type="hidden" name="emp_id" value="<?php echo e($getrec->id); ?>">
									<input type="text" class="textfield textfield_forms_resp" name= "fname" placeholder=" " value="<?php echo e($getrec->fname); ?>">
									<span class="placeholder"> First Name </span>
									<?php if($errors->has('fname')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('fname')); ?>

									</small>
									<?php endif; ?>
								</div> 

							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="text" name= "lname" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->lname); ?>">
									<span class="placeholder"> Last Name </span>
									<?php if($errors->has('lname')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('lname')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>

							<!-- emp CNIC -->
							<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="text" name= "cnic" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->cnic); ?>">
									<span class="placeholder"> Employee CNIC </span>
									<?php if($errors->has('cnic')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('cnic')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="text" name= "dob" class="textfield textfield_forms_resp" placeholder="YYYY-MM-DD" value="<?php echo e($getrec->date_of_birth); ?>">
									<span class="placeholder"> Date Of Birth </span>
									<?php if($errors->has('dob')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('dob')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="text" name= "gender" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->gender); ?>">
									<span class="placeholder"> Gender </span>
									<?php if($errors->has('gender')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('gender')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="Email" name= "email" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->email); ?>">
									<span class="placeholder"> Email </span>
									<?php if($errors->has('email')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('email')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="number" name= "number" class="textfield textfield_forms_resp" maxlength="10" placeholder=" " value="<?php echo e($getrec->phone_number); ?>">
									<span class="placeholder"> Phone Number </span>
									<?php if($errors->has('number')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('number')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="text" name= "address" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->address); ?>">
									<span class="placeholder"> Residing Address </span>
									<?php if($errors->has('address')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('address')); ?>

									</small>
									<?php endif; ?>
								</div> 
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="text" name= "city" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->city); ?>">
									<span class="placeholder"> City </span>
									<?php if($errors->has('city')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('city')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
					<!-- <label class="wrapper mt-4">
						<div class="emp_input_div">
							<input type="text" class="textfield textfield_forms_resp" placeholder=" " >
							<span class="placeholder"> Employee Grade </span>
						</div>
					</label> -->
					<!-- <label class="wrapper mt-4">
						<div class="emp_input_div">
							<input type="text" name= "dept" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->dept); ?>">
							<span class="placeholder"> Department </span>
							<?php if($errors->has('dept')): ?>
							<small class="text-danger">
								<?php echo e($errors->first('dept')); ?>

							</small>
							<?php endif; ?>
						</div>
					</label> -->
					<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="text" name= "qualification" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->qualification); ?>">
									<span class="placeholder"> Emp Qualification </span>
									<?php if($errors->has('qualification')): ?>
									<div class="text-danger">
										<?php echo e($errors->first('qualification')); ?>

									</div>
									<?php endif; ?>
								</div>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div ">
									<input type="number" name= "ex" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->experience); ?>">
									<span class="placeholder"> Experience In Year </span>
									<?php if($errors->has('ex')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('ex')); ?>

									</small>
									<?php endif; ?>
								</div>
							</label>
					<label class="wrapper mt-4">
								<div class="emp_input_div">

									<select name="dept" class="form-control">
										<?php $__currentLoopData = $d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($dd->id); ?>" <?php if($dd->id == $getrec->dept_id): ?> <?php echo e('selected'); ?>  <?php endif; ?> ><?php echo e($dd->dept_name); ?>

										</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</select>
								</div>
								<?php if($errors->has('dept')): ?>
									<small class="text-danger">
										<?php echo e($errors->first('dept')); ?>

									</small>
									<?php endif; ?>
							</label>
					
					<label class="wrapper mt-4">
						<div class="emp_input_div">
							<input type="text" name= "dateofjoining" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->date_of_joining); ?>">
							<span class="placeholder"> Date of Joining </span>
							<?php if($errors->has('dateofjoining')): ?>
							<small class="text-danger">
								<?php echo e($errors->first('dateofjoining')); ?>

							</small>
							<?php endif; ?>
						</div>
					</label>
					
					<label class="wrapper mt-4">
						<div class="emp_input_div">
							<input type="Password" name="password" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->password); ?>">
							<span class="placeholder"> New password </span>
							<?php if($errors->has('password')): ?>
							<small class="text-danger">
								<?php echo e($errors->first('password')); ?>

							</small>
							<?php endif; ?>
						</div>
					</label>
					<label class="wrapper mt-4">
						<div class="emp_input_div">
							<input type="Password" name= "cpassword" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e($getrec->confirm_password); ?>">
							<span class="placeholder"> Confirm Password </span>
							<?php if($errors->has('cpassword')): ?>
							<small class="text-danger">
								<?php echo e($errors->first('cpassword')); ?>

							</small>
							<?php endif; ?>
						</div>
					</label>
					<label class="wrapper mt-4">
						<div class="emp_input_div">									
							<input type="file" class="form-control textfield textfield_forms_resp" name="profile_image">
							<img src="<?php echo e(asset('uploads/emppic/'.$getrec->profile_image)); ?>" width="80px" height="80px" alt="Image">

							<!-- <span class="placeholder"> Browse </span> -->
							<?php if($errors->has('profile_image')): ?>
							<small class="text-danger">
								<?php echo e($errors->first('profile_image')); ?>

							</small>
							<?php endif; ?>
						</div>
					</label>
					<div class="row">
						<div class="col-md-3"></div>
						<div class="row">
							<div class="col-md-6 col-6">
								<div class="container-login100-form-btn m-t-32">
									<button type="submit" class="login100-form-btn">
										Update
									</button>
								</div>
							</div>
							<div class="col-md-6 col-6">
								<div class="container-login100-form-btn m-t-32">

									<a style="text-decoration:none" class="login100-form-btn" href="<?php echo e(url('allemp')); ?>">Back</a>
								</div>
							</div>
						</div>
						<div class="col-md-3"></div>
					</div>
				</form>
			</div>
			<div class="col-md-5">
				<img src="<?php echo e(asset('img/form.jpg')); ?>" alt="person" class="add_emp_form_pic img-fluid mt-n0"
				height="1000" width="997">
			</div>
		</div>
	</div>
</div>
</div>
</section> 
<?php $__env->stopSection(); ?>



<?php echo $__env->make('hr.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp\resources\views/hr/editemp.blade.php ENDPATH**/ ?>