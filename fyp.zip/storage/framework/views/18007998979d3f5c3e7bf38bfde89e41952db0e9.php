

<!-- Designation form start here -->
<style>
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button
{
	-webkit-appearance: none;
	margin: 0;
}
</style>
<?php $__env->startSection('desg'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('desgs'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="forms">

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-5 mt-3">
				<h1 class="font-weight-bold add_emp_heading"><u>Employees Designation</u></h1>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div class="card shadow-sm mt-4">
					<div class="card-body shadow">
						<?php if(session()->has('success')): ?>
						<div class="alert alert-success">
							<?php echo e(session()->get('success')); ?>

						</div>
						<?php endif; ?>
						<?php if(session()->has('error')): ?>
						<div class="alert alert-danger">
							<?php echo e(session()->get('error')); ?>

						</div>
						<?php endif; ?>
						<form method="POST" action="<?php echo e(url('/create2')); ?>" id="mybtn">
							<?php echo csrf_field(); ?>
							
							<div id="img_p"></div>
							
							
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="number" name="id" class="textfield textfield_forms_resp" placeholder=" " value="<?php echo e(old('id')); ?>" id="reg_id"  autocomplete="off" >
									<span class="placeholder">Registraton Number:</span>
								</div>
								<?php if($errors->has('id')): ?>
								<small class="text-danger">
									<?php echo e($errors->first('id')); ?>

								</small>
								<?php endif; ?>
							</label>
							<label class="wrapper mt-4">
								<!-- <div class="emp_input_div">
									
									<input type="text" class="textfield textfield_forms_resp" placeholder=" " name="fname">
									
									<span class="placeholder">Employee Name</span>
									<?php if($errors->has('fname')): ?>
							<small class="text-danger">
								<?php echo e($errors->first('fname')); ?>

							</small>
							<?php endif; ?>
						</div> -->

					</label>
					<label class="wrapper mt-4">
						<div class="emp_input_div" style="height: 49px;">
									<!-- <input type="text" class="textfield textfield_forms_resp" placeholder=" " name="desig" value="<?php echo e(old('desig')); ?>">
										<span class="placeholder">Select Designation</span> -->
										<select name="des" class="form-control border-0" style="">
										<?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php ($name=$n->designation_names); ?>
										<option value="" selected disabled hidden>Choose Designation</option>
										<option value="<?php echo e($n->id); ?>"> <?php echo e($name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</select>
									
								</div>
								<?php if($errors->has('des')): ?>
								<small class="text-danger">
									<?php echo e($errors->first('des')); ?>

								</small>
								<?php endif; ?>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="number" class="textfield textfield_forms_resp" placeholder=" " name="pay" value="<?php echo e(old('pay')); ?>" autocomplete="off">
									<span class="placeholder">Basic pay</span>
									
								</div>
								<?php if($errors->has('pay')): ?>
								<small class="text-danger">
									<?php echo e($errors->first('pay')); ?>

								</small>
								<?php endif; ?>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="number" class="textfield textfield_forms_resp" placeholder=" " name="travel" value="<?php echo e(old('travel')); ?>" autocomplete="off">
									<span class="placeholder">Travel Allowance</span>
									
								</div>
								<?php if($errors->has('travel')): ?>
								<small class="text-danger">
									<?php echo e($errors->first('travel')); ?>

								</small>
								<?php endif; ?>
							</label>
							<label class="wrapper mt-4">
								<div class="emp_input_div">
									<input type="number" class="textfield textfield_forms_resp" placeholder=" " name="medical" value="<?php echo e(old('medical')); ?>"  autocomplete="off">
									<span class="placeholder">Medical Allowance</span>
									
								</div>
								<?php if($errors->has('medical')): ?>
								<small class="text-danger">
									<?php echo e($errors->first('medical')); ?>

								</small>
								<?php endif; ?>
							</label>
							<div class="row">
								<div class="col-md-6 col-6">
									<div class="container-login100-form-btn m-t-32">
										<button type="submit" class="login100-form-btn">
											Save
										</button>
									</div>
								</div>
								<div class="col-md-6 col-6">
									<div class="container-login100-form-btn m-t-32">
										<input type="button" class="login100-form-btn" onclick="myFunction()" value="Clear">
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<img src="img/designation_img.jpg" alt="person" class=" img-fluid "
				height="1000" width="997">
			</div>
		</div>
	</div>
</section> 
<script>
	

	$(document).ready(function(){
		$('#reg_id').keyup(function(){
			var reg=$(this).val();
			
			if(reg!=0)
			{
				$.ajax({
					type:'GET',
					url: "<?php echo e(url('/')); ?>/get_image/"+reg

				}).done(function(data){
					
					if(data.status)
					{
						$('#img_p').html(`<img src="<?php echo e(url("/")); ?>/uploads/emppic/`+data.img+`"width="150px" height="150px" alt="Image">`);
					}
					else
					{
						$('#img_p').html(' ');
					}
				});
			}
		});

	});
	function myFunction() {
		document.getElementById("mybtn").reset();
	}
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('hr.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fyp\resources\views/hr/designation.blade.php ENDPATH**/ ?>