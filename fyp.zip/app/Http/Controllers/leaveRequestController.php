<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LeaveRequest;
use App\Models\addemployee;

class leaveRequestController extends Controller
{
    //
    public function leaves()
    {
    	
    	$leave = LeaveRequest::all();
    	// $emp = addemployee::query()->where('id', $leave->addemployee_id);
    	// $name= $emp->fname;
    	//dd($emp);
    	return view('hr.leaves',compact('leave'));
    }
}
